interface FishColor {
    val color: String
}